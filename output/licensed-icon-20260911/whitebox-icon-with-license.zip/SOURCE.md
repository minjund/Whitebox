# Whitebox icon

Adapted from Lucide `square-menu`, copyright (c) 2026 Lucide Icons and Contributors.
Use, modification and commercial distribution are permitted under the ISC License.
Include `LICENSE.txt` with copies or modified versions.

Upstream commit: `5d592a96aaeb4a3a09ffd8134f8f5ed878c9a0c5`

- SVG: https://github.com/lucide-icons/lucide/blob/5d592a96aaeb4a3a09ffd8134f8f5ed878c9a0c5/icons/square-menu.svg
- License: https://github.com/lucide-icons/lucide/blob/5d592a96aaeb4a3a09ffd8134f8f5ed878c9a0c5/LICENSE

Changes: two work-item strokes, shorter second stroke, charcoal/off-white colors,
padding and a rounded background. `icon.svg` is the modified master; PNG and ICO
were rendered from it. `upstream-square-menu.svg` preserves the original source.

This package records copyright permission for the source icon. It does not grant
exclusive rights or certify trademark clearance. No Dropbox artwork is included.

상업적으로 사용·수정·배포할 수 있는 ISC 라이선스 아이콘입니다.
재배포 시 `LICENSE.txt`를 함께 제공하세요. 상표권 검토를 완료한 것은 아닙니다.
